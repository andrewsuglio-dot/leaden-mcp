import "dotenv/config";
import express from "express";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { requireApiKey } from "./auth.js";
import { auditGbpPresence, auditGbpPresenceSchema } from "./tools/auditGbpPresence.js";
import { scanNicheOpportunity, scanNicheOpportunitySchema } from "./tools/scanNicheOpportunity.js";

function buildServer(): McpServer {
  const server = new McpServer({ name: "suglio-leadgen-mcp", version: "0.1.0" });

  server.registerTool(
    "audit_gbp_presence",
    {
      title: "Audit Google Business Profile",
      description:
        "Audits a local business's Google Business Profile presence: reviews, rating, website, and listing completeness. Returns identified gaps and a suggested outreach pitch angle.",
      inputSchema: auditGbpPresenceSchema,
    },
    async (args) => {
      const result = await auditGbpPresence(args);
      return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
    }
  );

  server.registerTool(
    "scan_niche_opportunity",
    {
      title: "Scan Local Niche Opportunity",
      description:
        "Scans a service niche in a city for real local competitor density, review strength, and fake-local/spam listing networks (detected via shared phone numbers). Returns an opportunity score for rank-and-rent targeting.",
      inputSchema: scanNicheOpportunitySchema,
    },
    async (args) => {
      const result = await scanNicheOpportunity(args);
      return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };
    }
  );

  return server;
}

const app = express();
app.use(express.json());

// Stateless mode: a fresh server + transport per request. This is the
// pattern the SDK recommends for simple, API-style remote MCP servers
// (no long-lived session state to manage or scale behind a load balancer).
app.post("/mcp", requireApiKey, async (req, res) => {
  try {
    const server = buildServer();
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    res.on("close", () => {
      transport.close();
      server.close();
    });
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (err) {
    console.error("MCP request error:", err);
    if (!res.headersSent) {
      res.status(500).json({
        jsonrpc: "2.0",
        error: { code: -32603, message: "Internal server error" },
        id: null,
      });
    }
  }
});

app.get("/health", (_req, res) => {
  res.json({ status: "ok", server: "suglio-leadgen-mcp" });
});

const PORT = process.env.PORT ? Number(process.env.PORT) : 3001;
app.listen(PORT, () => {
  console.log(`Suglio Lead-Gen MCP listening on http://localhost:${PORT}/mcp`);
});
