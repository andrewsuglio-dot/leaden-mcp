import { z } from "zod";
import { searchPlacesText } from "../places.js";

export const auditGbpPresenceSchema = {
  businessName: z.string().describe("The business name to audit, e.g. 'Suglio Roofing Co'"),
  city: z.string().describe("City the business operates in"),
  state: z.string().describe("US state abbreviation, e.g. 'OH'"),
};

type AuditArgs = {
  businessName: string;
  city: string;
  state: string;
};

/**
 * Pulls a business's public Google Business Profile data and scores how
 * complete/trustworthy the listing looks, plus a suggested outreach angle.
 */
export async function auditGbpPresence({ businessName, city, state }: AuditArgs) {
  const places = await searchPlacesText(`${businessName} in ${city}, ${state}`, 5);

  if (places.length === 0) {
    return {
      businessName,
      found: false,
      note: "No matching Google Business Profile found for this name/location. Double-check spelling or try a broader city.",
    };
  }

  const match = places[0];
  const gaps: string[] = [];

  if (!match.websiteUri) gaps.push("No website listed on the profile");
  if (!match.nationalPhoneNumber && !match.internationalPhoneNumber) {
    gaps.push("No phone number listed");
  }
  if ((match.userRatingCount ?? 0) < 10) {
    gaps.push("Fewer than 10 reviews — low trust signal for new customers");
  }
  if ((match.rating ?? 0) > 0 && (match.rating ?? 0) < 4.3) {
    gaps.push(`Rating of ${match.rating} is below the ~4.3 threshold most customers filter on`);
  }
  if (match.businessStatus && match.businessStatus !== "OPERATIONAL") {
    gaps.push(`Listing status is "${match.businessStatus}", not OPERATIONAL`);
  }

  let completenessScore = 100 - gaps.length * 15;
  completenessScore = Math.max(0, Math.min(100, completenessScore));

  return {
    businessName: match.displayName?.text ?? businessName,
    found: true,
    address: match.formattedAddress,
    rating: match.rating ?? null,
    reviewCount: match.userRatingCount ?? 0,
    hasWebsite: Boolean(match.websiteUri),
    completenessScore,
    gaps,
    pitchAngle:
      gaps.length > 0
        ? `Lead with: "${gaps[0]}" — it's the fastest, most visible win to open a conversation.`
        : "Profile is already in solid shape — pitch review velocity, photos, or content instead.",
  };
}
