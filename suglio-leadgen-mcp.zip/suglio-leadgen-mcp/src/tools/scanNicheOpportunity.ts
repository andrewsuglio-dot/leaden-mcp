import { z } from "zod";
import { searchPlacesText, type PlaceResult } from "../places.js";

export const scanNicheOpportunitySchema = {
  niche: z
    .string()
    .describe("The service niche to research, e.g. 'radon mitigation' or 'window tinting'"),
  city: z.string().describe("City to search in"),
  state: z.string().describe("US state abbreviation, e.g. 'OH'"),
};

type ScanArgs = {
  niche: string;
  city: string;
  state: string;
};

/**
 * Scans a niche/city combo for real competitor density vs. fake-local /
 * lead-reseller spam networks, using shared-phone-number clustering as the
 * spam signal — the same heuristic used for manual quote-search research.
 */
export async function scanNicheOpportunity({ niche, city, state }: ScanArgs) {
  const places = await searchPlacesText(`${niche} in ${city}, ${state}`, 20);
  const operational = places.filter(
    (p) => !p.businessStatus || p.businessStatus === "OPERATIONAL"
  );

  // Cluster listings by phone number. Multiple "different" business names
  // sharing one phone number is a strong fake-local / call-center signal.
  const phoneMap = new Map<string, string[]>();
  for (const p of operational) {
    const phone = p.nationalPhoneNumber || p.internationalPhoneNumber;
    if (!phone) continue;
    const name = p.displayName?.text ?? "Unknown";
    phoneMap.set(phone, [...(phoneMap.get(phone) ?? []), name]);
  }

  const suspectedSpamClusters = [...phoneMap.entries()]
    .filter(([, names]) => names.length > 1)
    .map(([phone, names]) => ({ phone, listings: names }));

  const spamListingCount = suspectedSpamClusters.reduce(
    (sum, cluster) => sum + cluster.listings.length,
    0
  );
  const likelyRealCompetitors = Math.max(0, operational.length - spamListingCount);

  const reviewCounts = operational.map((p) => p.userRatingCount ?? 0).filter((n) => n > 0);
  const averageReviewCount =
    reviewCounts.length > 0
      ? Math.round(reviewCounts.reduce((a, b) => a + b, 0) / reviewCounts.length)
      : 0;

  const listingsMissingWebsite = operational.filter((p) => !p.websiteUri).length;

  // Opportunity heuristic: fewer real competitors, thinner review counts, and
  // more listings missing a website all point toward an underserved market.
  let opportunityScore = 50;
  opportunityScore += Math.max(0, 10 - likelyRealCompetitors) * 4;
  opportunityScore += averageReviewCount < 15 ? 15 : averageReviewCount < 40 ? 5 : -10;
  opportunityScore +=
    operational.length > 0 ? Math.round((listingsMissingWebsite / operational.length) * 20) : 0;
  opportunityScore = Math.max(0, Math.min(100, Math.round(opportunityScore)));

  const verdict =
    opportunityScore >= 70
      ? "Underserved — worth building a rank-and-rent site for this niche/city."
      : opportunityScore >= 45
        ? "Moderate competition — viable with a strong site and review velocity."
        : "Saturated — look at a neighboring city or a narrower sub-niche.";

  return {
    niche,
    location: `${city}, ${state}`,
    totalListingsFound: operational.length,
    likelyRealCompetitors,
    suspectedSpamClusters,
    averageReviewCount,
    listingsMissingWebsite,
    opportunityScore,
    verdict,
  };
}

// Keep this export around so `PlaceResult` stays a used type if this file's
// logic is extended later (e.g. per-listing breakdown in the tool output).
export type { PlaceResult };
