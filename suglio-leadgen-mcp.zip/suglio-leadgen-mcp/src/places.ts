// Thin wrapper around the Places API (New) Text Search endpoint.
// Docs: https://developers.google.com/maps/documentation/places/web-service/text-search

const FIELD_MASK = [
  "places.id",
  "places.displayName",
  "places.formattedAddress",
  "places.nationalPhoneNumber",
  "places.internationalPhoneNumber",
  "places.websiteUri",
  "places.rating",
  "places.userRatingCount",
  "places.types",
  "places.businessStatus",
].join(",");

export interface PlaceResult {
  id: string;
  displayName?: { text: string; languageCode?: string };
  formattedAddress?: string;
  nationalPhoneNumber?: string;
  internationalPhoneNumber?: string;
  websiteUri?: string;
  rating?: number;
  userRatingCount?: number;
  types?: string[];
  businessStatus?: string;
}

interface SearchTextResponse {
  places?: PlaceResult[];
}

/**
 * Runs a Places API (New) Text Search and returns the raw place results.
 * Requires GOOGLE_PLACES_API_KEY to be set in the environment.
 */
export async function searchPlacesText(
  textQuery: string,
  maxResultCount = 20
): Promise<PlaceResult[]> {
  const apiKey = process.env.GOOGLE_PLACES_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GOOGLE_PLACES_API_KEY is not set. Add it to your .env file (see .env.example)."
    );
  }

  const res = await fetch("https://places.googleapis.com/v1/places:searchText", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": apiKey,
      "X-Goog-FieldMask": FIELD_MASK,
    },
    body: JSON.stringify({ textQuery, maxResultCount }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Places API error (${res.status}): ${errText}`);
  }

  const data = (await res.json()) as SearchTextResponse;
  return data.places ?? [];
}
