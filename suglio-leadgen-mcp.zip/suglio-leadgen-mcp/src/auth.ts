import type { Request, Response, NextFunction } from "express";

// v1: a static allow-list pulled from an env var (comma-separated keys).
// This is the right amount of auth for a service-to-service API product —
// see README for how to swap this for a Supabase-backed per-customer lookup
// tied to Stripe subscription status once you're ready to sell access.
function loadValidKeys(): Set<string> {
  return new Set(
    (process.env.MCP_API_KEYS ?? "")
      .split(",")
      .map((k) => k.trim())
      .filter(Boolean)
  );
}

export function requireApiKey(req: Request, res: Response, next: NextFunction): void {
  const validKeys = loadValidKeys();
  const header = req.headers.authorization ?? "";
  const key = header.startsWith("Bearer ") ? header.slice(7) : undefined;

  if (!key || !validKeys.has(key)) {
    res.status(401).json({
      jsonrpc: "2.0",
      error: { code: -32001, message: "Unauthorized: missing or invalid API key" },
      id: null,
    });
    return;
  }

  next();
}
