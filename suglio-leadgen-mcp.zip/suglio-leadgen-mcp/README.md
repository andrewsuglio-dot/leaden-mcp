# Suglio Lead-Gen MCP

A remote MCP server exposing two lead-gen intelligence tools over Streamable HTTP,
gated by a Bearer API key. Built to run in Claude, other MCP-compatible clients,
or be called directly over HTTP.

## Tools

### `audit_gbp_presence`
Input: `businessName`, `city`, `state`
Pulls the business's public Google Business Profile data and returns a
completeness score, identified gaps (no website, low review count, sub-4.3
rating, etc.), and a suggested outreach pitch angle.

### `scan_niche_opportunity`
Input: `niche`, `city`, `state`
Searches a niche in a city and scores the opportunity: counts likely-real
competitors vs. suspected fake-local/spam listings (detected by clustering
results that share a phone number), average review count, and how many
listings are missing a website. Returns a 0–100 opportunity score and a
verdict.

## Setup

```bash
npm install
cp .env.example .env
```

Edit `.env`:
- `GOOGLE_PLACES_API_KEY` — from Google Cloud Console → APIs & Services →
  enable "Places API (New)" → Credentials → create an API key. Free tier
  covers a meaningful number of calls/month; check current pricing in the
  console before heavy use.
- `MCP_API_KEYS` — comma-separated list of keys you'll hand out to whoever
  is allowed to call this server. Generate one with:
  ```bash
  node -e "console.log(require('crypto').randomBytes(24).toString('hex'))"
  ```

## Run

```bash
npm run dev     # hot-reload for development
# or
npm run build && npm start   # production
```

Server listens on `http://localhost:3001/mcp` (health check at `/health`).

## Test it

**Quick curl test** (no MCP client needed):

```bash
curl -X POST http://localhost:3001/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer YOUR_MCP_API_KEY" \
  -d '{"jsonrpc":"2.0","method":"tools/call","params":{"name":"scan_niche_opportunity","arguments":{"niche":"window tinting","city":"Lebanon","state":"OH"}},"id":1}'
```

**With MCP Inspector** (visual tool tester):

```bash
npx @modelcontextprotocol/inspector
```
Point it at `http://localhost:3001/mcp`, set the Authorization header to
`Bearer YOUR_MCP_API_KEY`, and call the tools from the UI.

**In Claude Desktop / Claude Code config** (once deployed somewhere public):

```json
{
  "mcpServers": {
    "suglio-leadgen": {
      "url": "https://your-deployed-url.com/mcp",
      "headers": { "Authorization": "Bearer YOUR_MCP_API_KEY" }
    }
  }
}
```

## Next steps toward monetization

1. **Swap the auth allow-list for Supabase.** Right now `src/auth.ts` checks
   keys against an env var. Replace `loadValidKeys()` with a lookup against
   a `customers` table (key → active/inactive), so you can issue and revoke
   keys per paying customer.
2. **Wire Stripe.** On successful checkout/subscription webhook, generate a
   key, write it to Supabase, and email it to the customer. On cancellation,
   flip their row to inactive.
3. **Deploy to Netlify.** Netlify Functions can run this Express app with
   minor adapter changes (or deploy as a small always-on Node service if you
   want to avoid cold starts on a stateless-per-request design like this).
4. **Add usage metering** if you want usage-based billing instead of flat
   subscription — log each tool call (key, tool name, timestamp) to Supabase
   and roll it up for Stripe usage records.
5. **Consider a `get_scored_leads` tool** once you have an actual pipeline of
   generated/qualified leads to serve, rather than just live research tools.
